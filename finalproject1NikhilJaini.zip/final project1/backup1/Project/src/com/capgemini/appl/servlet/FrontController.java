package com.capgemini.appl.servlet;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.Location;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;
import com.capgemini.appl.service.UniversityServiceImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RequestDispatcher requestDispatcher;
	private String nextJspString;
	String msg = null;
	private ServletContext ctxContext;
	UniversityService service = null;
	Application appl;

	public FrontController() {
		super();
		try {
			service = new UniversityServiceImpl();
			appl = new Application();
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void init() throws ServletException {

	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getServletPath();
		switch (command) {
		case "/showApplicant.do": {
			try {
				HttpSession log = request.getSession(false);
				System.out.println("xyxyyx");
				String logRight = (String) log.getAttribute("logRight");
				System.out.println((String) log.getAttribute("logRight"));
				if (logRight.equals("mac")) {
					System.out.println("xyxyyx");
					try {
						System.out.println("xyxyyx");
						List<Application> list = service.showApplications();
						request.setAttribute("list", list);
						nextJspString = "/showApplicant.jsp";
					} catch (UniversityAdmissionException e) {
						// TODO Auto-generated catch block
						// e.printStackTrace();
						request.setAttribute("msg", e);
						nextJspString = "/error.jsp";
					}
				} else {
					nextJspString = "/login.jsp";

				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				nextJspString = "/login.jsp";
				e.printStackTrace();
			}
		}
			break;

		case "/interview.do": {

			int applicationid = Integer.parseInt(request
					.getParameter("applicant"));
			String full_name = request.getParameter("name");
			request.setAttribute("Application_id", applicationid);
			request.setAttribute("full_name", full_name);
			nextJspString = "/interviewDate.jsp";

		}
			break;
		case "/accept.do": {
			Boolean checkDateBoolean = false;

			int applicationid = Integer.parseInt(request.getParameter("id"));
			String d = request.getParameter("interview").toString();

			// ///////////////

			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date;

			try {
				date = sdf1.parse(d);
				java.sql.Date dateCompare = new java.sql.Date(Calendar
						.getInstance().getTime().getTime());

				java.sql.Date sqlStartDate = new Date(date.getTime());
				if (sqlStartDate.compareTo(dateCompare) > 0) {
					checkDateBoolean = true;

				} else if (sqlStartDate.toString().trim()
						.equals(dateCompare.toString().trim())) {
					checkDateBoolean = true;

				} else if (sqlStartDate.compareTo(dateCompare) < 0) {
					checkDateBoolean = false;
				}
				if (checkDateBoolean) {
					Application application = new Application(applicationid,
							"accepted", sqlStartDate);
					service.acceptOrRejectApplication(application);
					nextJspString = "/showApplicant.do";
				}

				else {

					request.setAttribute("msg", "please Enter Correct Date");
					nextJspString = "/error.jsp";

				}

			} catch (ParseException | UniversityAdmissionException e) {

				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		case "/reject.do": {

			int applicationid = Integer.parseInt(request
					.getParameter("applicant"));
			Application application = new Application(applicationid, "rejected");

			try {
				service.acceptOrRejectApplication(application);
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}
			nextJspString = "/showApplicant.do";

		}
			break;

		case "/addProgram.do": {
			String ProgramName = request.getParameter("ProgramName");
			String description = request.getParameter("description");
			String applicantEligility = request.getParameter("eligibility");
			int duration = Integer.parseInt(request.getParameter("duration"));
			String degree_certificate_offered = request
					.getParameter("degree_certificate_offered");
			ProgramsOffered programsOffered = new ProgramsOffered(ProgramName,
					description, applicantEligility, duration,
					degree_certificate_offered);
			try {
				boolean success = service.addProgram(programsOffered);
				if (success) {
					nextJspString = "/showAllProgram.do";

				} else {

				}
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		case "/showAllProgram.do": {
			try {
				List<ProgramsOffered> list = service.showProgramsOffereds();
				request.setAttribute("list", list);
				nextJspString = "/showAllProgram.jsp";

			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		case "/updateProgram.do": {
			HttpSession session = request.getSession(true);
			String ProgramName = request.getParameter("ProgramName");
			String description = request.getParameter("description");
			String applicantEligility = request
					.getParameter("applicantEligility");
			int duration = Integer.parseInt(request.getParameter("duration"));
			String degree_certificate_offered = request
					.getParameter("degree_certificate_offered");
			// ////////////////////////
			session.setAttribute("ProgramName", ProgramName);
			// ////////////////

			ProgramsOffered programsOffered = new ProgramsOffered(ProgramName,
					description, applicantEligility, duration,
					degree_certificate_offered);
			request.setAttribute("programsOffered", programsOffered);
			nextJspString = "/showProgram.jsp";

		}
			break;

		case "/updateOneProgram.do": {
			// String ProgramName = request.getParameter("ProgramName");
			HttpSession session = request.getSession(false);
			String ProgramName = (String) session.getAttribute("ProgramName");
			session.invalidate();
			String description = request.getParameter("description");
			String applicantEligility = request.getParameter("eligibility");
			int duration = Integer.parseInt(request.getParameter("duration"));
			String degree_certificate_offered = request
					.getParameter("degree_certificate_offered");

			ProgramsOffered programsOffered = new ProgramsOffered(ProgramName,
					description, applicantEligility, duration,
					degree_certificate_offered);
			try {
				boolean updateprogram = service.updateProgram(programsOffered);
				if (updateprogram) {
					nextJspString = "/showAllProgram.do";
				}
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		case "/delteProgram.do": {
			String ProgramName = request.getParameter("ProgramName");
			try {
				boolean programdelete = service.deleteProgram(ProgramName);
				if (programdelete) {
					nextJspString = "/showAllProgram.do";

				}
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		case "/addSingleProgram.do": {
			nextJspString = "/addProgram.jsp";
		}
			break;
		// ////////////////////////////////////////Nehali

		case "/login.do": {
			nextJspString = "login.jsp";
		}
			break;
		case "/authenticate.do": {
			System.out.println("Authenticate");
			String user = request.getParameter("user");
			String pwd = request.getParameter("pwd");
			System.out.println(user + " " + pwd);
			try {
				String role = service.isUserAuthanticate(user, pwd);
				if (role.equals("mac")) {
					HttpSession log = request.getSession(true);
					log.setAttribute("logRight", role);
					System.out.println(role);
					nextJspString = "member.jsp";
				}

				else if (role.equals("admin")) {
					nextJspString = "admin.jsp";
					HttpSession log = request.getSession(true);
					log.setAttribute("logRight", role);
				}
			} catch (UniversityAdmissionException e) {
				msg = "Not Authorized person of administrator or members of admission committee";
				request.setAttribute("msg", msg);
				nextJspString = "/login.jsp";

			}

		}
			break;

		case "/takeInterview.do": {
			List<ProgramsScheduled> schedule;
			try {
				schedule = service.getAllProgramSheduled();
				request.setAttribute("data", schedule);
				nextJspString = "showSheduleDetail.jsp";
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
			break;
		case "/retriveApplication.do": {
			System.out.println("retrive");

			String id = request.getQueryString();
			String ScheduleId = id.substring(3);
			System.out.println(ScheduleId);
			List<Application> applicationList = null;
			try {
				applicationList = service
						.getApplicationOnSheduledId(ScheduleId);

				if (applicationList.isEmpty()) {
					msg = "participants Not exists";
					request.setAttribute("msg", msg);
					nextJspString = "/error.jsp";

				} else {

					System.out.println("hi" + applicationList);
					request.setAttribute("data", applicationList);
					nextJspString = "showAllApplicantsDetail.jsp";
				}

			} catch (UniversityAdmissionException e) {
				e.printStackTrace();
			}

		}
			break;
		case "/confirmed.do": {
			String id = request.getQueryString();
			String applicationId = id.substring(3);
			int applId = Integer.parseInt(applicationId);
			String status = "confirmed";
			System.out.println(applId);
			try {
				boolean update = service.updateApplicationDB(applId, status);
				if (update == true) {
					List<ProgramsScheduled> schedule = service
							.getAllProgramSheduled();
					request.setAttribute("data", schedule);
					nextJspString = "showSheduleDetail.jsp";
				} else {
					msg = "Unable to accept application.";
					request.setAttribute("msg", msg);
					nextJspString = "/error.jsp";
				}

			} catch (UniversityAdmissionException e) {

				e.printStackTrace();
			}

		}
			break;
		case "/rejectCandidate.do": {
			String id = request.getQueryString();
			String applicationId = id.substring(3);
			int applId = Integer.parseInt(applicationId);
			String status = "rejected";
			System.out.println(applId);
			try {
				boolean update = service.updateApplicationDB(applId, status);
				if (update == true) {
					List<ProgramsScheduled> schedule = service
							.getAllProgramSheduled();
					request.setAttribute("data", schedule);
					nextJspString = "showSheduleDetail.jsp";
				} else {
					msg = "Unable to reject application.";
					request.setAttribute("msg", msg);
					nextJspString = "/error.jsp";
				}

			} catch (UniversityAdmissionException e) {

				e.printStackTrace();
			}

		}
			break;
		case "/home.do": {
			nextJspString = "login.jsp";
		}
			break;

		case "/logOut.do": {
			HttpSession log = request.getSession(false);
			log.invalidate();
			nextJspString = "login.jsp";
		}
			break;

		// ////////////////////////////////////////

		case "/showProgramScheduled.do": {

			System.out.println("ProgramScheduled");
			List<ProgramsScheduled> scheduleList = null;
			try {
				scheduleList = service.getAllProgramSheduled();

				if (scheduleList.isEmpty()) {
					msg = "Schedule Detail Not exists";
					request.setAttribute("msg", msg);
					nextJspString = "/error.jsp";

				} else {

					System.out.println("hi" + scheduleList);
					request.setAttribute("data", scheduleList);
					nextJspString = "candidateReport.jsp";
				}

			} catch (UniversityAdmissionException e) {
				e.printStackTrace();
			}

		}
			break;

		case "/statusReport.do": {

			int id = Integer.parseInt(request.getParameter("id"));

			List<Application> myList = null;
			try {

				myList = service.showApplicantInfo(id);
				System.out.println("In Controller" + myList);
				if (myList.isEmpty()) {

					String error = "Please enter valid input";
					System.out.println(error);
					request.setAttribute("errorMsg", error);
					nextJspString = "candidateReport.jsp";
					throw new UniversityAdmissionException(
							"User has not entered valid input");

				} else {
					request.setAttribute("applicantinfo", myList);
					nextJspString = "candidateInfo.jsp";

				}

			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}

		}
			break;
		// ////////////////////////////////
		// ////////////////////////////////Pranali

		// ///////////////////////
		case "/programReport.do": {

			java.sql.Date sstartDate = null;
			java.sql.Date eendDate = null;

			String startdate = request.getParameter("startdate");
			String enddate = request.getParameter("enddate");

			SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd");
			try {
				java.util.Date startdate1 = formatter1.parse(startdate);
				System.out.println(startdate);
				sstartDate = new Date(startdate1.getTime());
				System.out.println(sstartDate);

				java.util.Date endDate1 = formatter1.parse(enddate);
				System.out.println(enddate);
				eendDate = new Date(endDate1.getTime());
				System.out.println(eendDate);

			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			List<ProgramsScheduled> myList = null;

			try {
				myList = service.showProgramInfo(sstartDate, eendDate);
				// System.out.println(myList);
				if (myList.isEmpty()) {
					String error = "Please Enter Valid Data";

					request.setAttribute("errorMsg", error);
					nextJspString = "programReport.jsp";
					throw new UniversityAdmissionException(
							"Please enter valid start date and end date");
				} else {
					request.setAttribute("programinfo", myList);
					nextJspString = "programInfo.jsp";

				}
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			break;

		}

		// ///////////////////////

		// //////////////////////////////////////////Pooja

		case "/showDetails.do": {
			List<ProgramsOffered> myList = null;
			try {
				myList = service.showAll();
			} catch (UniversityAdmissionException e) {

				e.printStackTrace();
			}
			request.setAttribute("data", myList);
			nextJspString = "programInformation.jsp";
			break;
		}
		case "/getid.do": {
			System.out.println("In getid do");
			int id=Integer.parseInt(request.getParameter("id"));
			System.out.println(id);
			request.setAttribute("id", id);
			nextJspString = "application.jsp";

			break;
		}

		case "/loadViewstatus.do": {
			System.out.println("asdsad");
			nextJspString = "viewStatus.jsp";
			break;
		}
		case "/viewstatus.do": {

			String id = request.getParameter("application_id");
			System.out.println(id);
			int id1 = Integer.parseInt(id);

			try {
				System.out.println("In try");
				Application status = service.showStatus(id1);
				System.out.println(status);
				if (status.getApplication_id() == 0) {
					request.setAttribute("msg", "Applicant not found");
					nextJspString = "viewStatus.jsp";
				} else {
					request.setAttribute("status", status);
					nextJspString = "status.jsp";
				}

			} catch (UniversityAdmissionException e) {

				e.printStackTrace();
			}

			break;

		}
		case "/insert.do": {
			int id = 0;
			try {

				try {
					id = service.getApplicationId();
				} catch (UniversityAdmissionException e1) {

					e1.printStackTrace();
				}

				String name = request.getParameter("name");

				String dob = request.getParameter("dob");
				java.util.Date date = new SimpleDateFormat("dd-MM-yyyy")
						.parse(dob);
				java.sql.Date sqldate = new java.sql.Date(date.getTime());
				// appl.setDate_of_birth(sqldate);

				String hqual = request.getParameter("hqual");
				int marks = Integer.parseInt(request.getParameter("marks"));
				String goal = request.getParameter("goal");
				String email = request.getParameter("email");
				String sid = request.getParameter("schedulprogram");
				String status = request.getParameter("status");
				String programId = request.getParameter("programId");
				/*
				 * String interviewdate=request.getParameter("interviewdate");
				 * java.util.Date date1=new
				 * SimpleDateFormat("dd-MM-yyyy").parse(interviewdate);
				 * java.sql.Date sqldate1=new java.sql.Date(date1.getTime());
				 */
				// appl.setDate_Of_Interview(sqldate1);

				// service.addApplicant(id,name,dob,sqldate,hqual,marks,goal,email,sid,status,sqldate1);

				appl.setApplication_id(id);
				appl.setFull_name(name);
				appl.setDate_of_birth(sqldate);
				appl.setHighest_qualification(hqual);
				appl.setMarks_obtained(marks);
				appl.setGoals(goal);
				appl.setEmail_id(email);
				appl.setScheduled_program_id(sid);
				appl.setStatus(status);
				appl.setScheduled_program_id(programId);
				try {
					int id1 = service.addApplicant(appl);
					request.setAttribute("Id", id1);
					/*
					 * int program_id=service.getProgramId();
					 * request.setAttribute("proId", program_id);
					 */
					nextJspString = "success.jsp";
				} catch (UniversityAdmissionException e) {

					e.printStackTrace();
				}
			} catch (NumberFormatException e) {

				e.printStackTrace();
			} catch (ParseException e) {

				e.printStackTrace();
			}

			break;
		}
		// /////////////////////////////////////
		// /////////////////////////////////////////////nehali update
		case "/ProgramOffered.do": {
			System.out.println("ProgramOffered");
			List<ProgramsOffered> programmList = null;
			try {
				programmList = service.getAllProgramDetails();

				if (programmList.isEmpty()) {
					msg = "Program Detail Not exists";
					request.setAttribute("msg", msg);
					nextJspString = "/error.jsp";

				} else {

					System.out.println("hi" + programmList);
					request.setAttribute("data", programmList);
					nextJspString = "showAllProgramsDetail.jsp";
				}

			} catch (UniversityAdmissionException e) {
				e.printStackTrace();
			}

		}
			break;

		case "/addShedule.do": {
			System.out.println("addShedule");
			String name = request.getQueryString();
			String prgmName = name.substring(3);
			System.out.println(prgmName);
			request.setAttribute("data", prgmName);
			nextJspString = "addScheduleDetails.jsp";

		}
			break;

		case "/insertScheduleDetail.do": {
			System.out.println("insertScheduleDetail");
			String prgmName = request.getParameter("prgmName");
			String city = request.getParameter("city");
			String hstate = request.getParameter("hstate");
			String zip = request.getParameter("zip");
			String startdate = request.getParameter("start_date").toString();
			String endDate = request.getParameter("end_date").toString();
			String session = request.getParameter("sessions_per_week");
			int ses = Integer.parseInt(session);
			Location loc = new Location();
			loc.setCity(city);
			loc.setHstate(hstate);
			loc.setZip(zip);
			String locationId = null;
			try {
				System.out.println("hiiiiii");
				locationId = service.insertLocationDetails(loc);
				System.out.println("lId" + locationId);
			} catch (UniversityAdmissionException e1) {
				// TODO Auto-generated catch block
				request.setAttribute("msg", e1.getMessage());
				nextJspString = "/error.jsp";
			}
			ProgramsScheduled schedule = new ProgramsScheduled();
			schedule.setProgramName(prgmName);
			schedule.setLocationID(locationId);

			Boolean checkDateBoolean = false;
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date dateStart;
			java.util.Date dateEnd;

			try {
				dateStart = sdf1.parse(startdate);
				dateEnd = sdf1.parse(endDate);

				java.sql.Date sqlStartDate = new Date(dateStart.getTime());
				java.sql.Date sqlEndDate = new Date(dateEnd.getTime());
				System.out.println("date" + sqlStartDate + " " + sqlEndDate);

				System.out.println(sqlStartDate.compareTo(sqlEndDate));

				if (sqlStartDate.compareTo(sqlEndDate) < 0) {
					checkDateBoolean = true;

				} else if (sqlStartDate.toString().trim()
						.equals(sqlEndDate.toString().trim())) {
					checkDateBoolean = true;

				} else if (sqlStartDate.compareTo(sqlEndDate) > 0) {
					checkDateBoolean = false;
				}

				System.out.println("date" + checkDateBoolean);
				if (checkDateBoolean) {
					schedule.setStart_date(sqlStartDate);
					schedule.setEnd_date(sqlEndDate);
					schedule.setSessions_per_week(ses);
					boolean result = service.insertScheduledDetails(schedule);
					System.out.println("Insertion result" + result);
					if (result) {
						msg = "Schedule Detail inserted Successfully";
						request.setAttribute("msg", msg);
						nextJspString = "/error.jsp";

					} else {
						msg = "Insertion of Schedule Detail Failed";
						request.setAttribute("msg", msg);
						nextJspString = "/error.jsp";

					}

				}

				else {

					request.setAttribute("msg", "please Enter Correct Date");
					nextJspString = "/error.jsp";

				}

			} catch (ParseException | UniversityAdmissionException e) {

				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;

		case "/ProgramScheduled.do": {

			System.out.println("ProgramScheduled");
			List<ProgramsScheduled> scheduleList = null;
			try {
				scheduleList = service.getAllProgramSheduled();

				if (scheduleList.isEmpty()) {
					msg = "Schedule Detail Not exists";
					request.setAttribute("msg", msg);
					nextJspString = "/error.jsp";

				} else {

					System.out.println("hi" + scheduleList);
					request.setAttribute("data", scheduleList);
					nextJspString = "showAllScheduleForDelete.jsp";
				}

			} catch (UniversityAdmissionException e) {
				e.printStackTrace();
			}

		}
			break;
		case "/showAllScheduleForDelete.do": {

			String id = request.getQueryString();
			String ScheduleId = id.substring(3);
			System.out.println(ScheduleId);
			try {
				boolean result = service.deleteSchedule(ScheduleId);
				if (result) {
					msg = "Schedule Detail Deleted";
					request.setAttribute("msg", msg);
					nextJspString = "/ProgramScheduled.do";

				} else {

					msg = "Deletion of Schedule Failed";
					request.setAttribute("msg", msg);
					nextJspString = "/error.jsp";

				}
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				request.setAttribute("msg", e.getMessage());
				nextJspString = "/error.jsp";
			}

		}
			break;

		// ////////////////////////modified
		case "/getScheduleProgram.do": {
			try {
				String programName = request.getParameter("id");
				System.out.println(programName);
				List<ProgramsScheduled> list = service
						.getAllProgramSheduled(programName);
				request.setAttribute("list", list);
				nextJspString = "/sheduledDetailsForApply.jsp";

			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		}
		System.out.println(nextJspString);
		requestDispatcher = request.getRequestDispatcher(nextJspString);
		requestDispatcher.forward(request, response);

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	public void destroy() {
	}

}
