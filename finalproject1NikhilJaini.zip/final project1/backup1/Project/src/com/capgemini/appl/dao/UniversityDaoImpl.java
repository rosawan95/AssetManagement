package com.capgemini.appl.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.Location;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.util.JndiUtil;

public class UniversityDaoImpl implements UniversityDao {
	private JndiUtil util = null;

	public UniversityDaoImpl() throws UniversityAdmissionException {
		try {
			util = new JndiUtil();
		} catch (UniversityAdmissionException e) {
			throw new UniversityAdmissionException("Error In JNDI Connection");
		}
	}

	@Override
	public List<Application> showApplications()
			throws UniversityAdmissionException {

		// SHOWING DEATILS
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		List<Application> list = new ArrayList<Application>();

		String Query = "select * from Application where status ='applied' ";
		try {

			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			rs = stat.executeQuery();

			while (rs.next()) {
				int Application_id = rs.getInt("Application_id");
				String full_name = rs.getString("full_name");
				java.sql.Date date_of_birth = rs.getDate("date_of_birth");
				String highest_qualification = rs
						.getString("highest_qualification");
				int marks_obtained = rs.getInt("marks_obtained");

				String goals = rs.getString("goals");
				String email_id = rs.getString("email_id");
				String Scheduled_program_id = rs
						.getString("Scheduled_program_id");
				String status = rs.getString("status");
				java.sql.Date Date_Of_Interview = rs
						.getDate("Date_Of_Interview");

				Application application = new Application(Application_id,
						full_name, date_of_birth, highest_qualification,
						marks_obtained, goals, email_id, Scheduled_program_id,
						status, Date_Of_Interview);

				list.add(application);
			}

			return list;

		} catch (SQLException e) {
			throw new UniversityAdmissionException("UNABLE TO FETCH DATA" + e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					if (stat != null) {
						stat.close();
					}
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					throw new UniversityAdmissionException(
							"Connection Closing failed");
				}
			}

		}

	}

	@Override
	public boolean addProgram(ProgramsOffered p)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = "insert into Programs_Offered values(?,?,?,?,?) ";
		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, p.getProgramName());
			stat.setString(2, p.getDescription());
			stat.setString(3, p.getApplicantEligility());
			stat.setInt(4, p.getDuration());
			stat.setString(5, p.getDegree_certificate_offered());
			rs = stat.executeQuery();
			if (rs.next()) {

				return true;

			} else {

				throw new UniversityAdmissionException(
						"UNABLE TO INSERT>> USER REGESTRATION FAILED");

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = " DELETE FROM Programs_Offered WHERE ProgramName=? ";
		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, ProgramName);
			rs = stat.executeQuery();
			if (rs.next()) {

				return true;

			} else {

				throw new UniversityAdmissionException("CAN NOT DELETE DATA");

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		String Query = "UPDATE Programs_Offered SET description = ?, applicant_eligibility=?,duration=?,degree_certificate_offered = ? WHERE ProgramName=? ";

		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, p.getDescription());
			stat.setString(2, p.getApplicantEligility());
			stat.setInt(3, p.getDuration());
			stat.setString(4, p.getDegree_certificate_offered());
			stat.setString(5, p.getProgramName());
			int r = stat.executeUpdate();
			if (r >= 1) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			// throw new UniversityAdmissionException(
			// "CAN NOT UPADTE INTO Programs_Offered");
			e1.printStackTrace();
		}
		return false;

	}

	@Override
	public boolean acceptOrRejectApplication(Application application)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		String Query = "UPDATE Application SET status = ?, Date_Of_Interview=? WHERE Application_id=? ";

		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, application.getStatus());
			stat.setDate(2, application.getDate_Of_Interview());
			stat.setInt(3, application.getApplication_id());
			rs = stat.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			throw new UniversityAdmissionException(
					"CAN NOT UPADTE INTO Application");

		}

	}

	@Override
	public List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException {

		// SHOWING DEATILS
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;
		List<ProgramsOffered> list = new ArrayList<ProgramsOffered>();

		String Query = "select * from Programs_Offered ";
		try {

			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			rs = stat.executeQuery();

			while (rs.next()) {

				String degree_certificate_offered = rs
						.getString("degree_certificate_offered");
				int duration = rs.getInt("duration");
				String ProgramName = rs.getString("ProgramName");
				String applicantEligility = rs
						.getString("applicant_eligibility");
				String description = rs.getString("description");
				ProgramsOffered programsOffered = new ProgramsOffered(
						ProgramName, description, applicantEligility, duration,
						degree_certificate_offered);
				list.add(programsOffered);
			}

			return list;

		} catch (SQLException e) {
			// throw new UniversityAdmissionException("UNABLE TO FETCH DATA");
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
					if (stat != null) {
						stat.close();
					}
					if (connection != null) {
						connection.close();
					}
				} catch (SQLException e) {
					throw new UniversityAdmissionException(
							"Connection Closing failed");
				}
			}

		}
		return list;

	}

	public Users getUserDetail(String userName)
			throws UniversityAdmissionException {
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query = "SELECT password, role FROM Users WHERE login_id=?";

		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, userName);
			rs = pstm.executeQuery();
			System.out.println("Hiii1");
			if (rs.next()) {
				String password = rs.getString("PASSWORD");
				String role = rs.getString("role");
				Users user = new Users(userName, password, role);

				System.out.println("Hiii1" + user);
				return user;

			} else {

				throw new UniversityAdmissionException(" Wrong UserName");
			}

		} catch (SQLException e) {

			throw new UniversityAdmissionException("No jndi connection", e);

		} finally {
		}
	}

	@Override
	public List<ProgramsScheduled> getAllProgramSheduled()
			throws UniversityAdmissionException {

		List<ProgramsScheduled> programList = new ArrayList<ProgramsScheduled>();
		Connection conn = null;

		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query = "SELECT * FROM Programs_Scheduled";
		System.out.println("ps1");

		try {

			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			rs = pstm.executeQuery();

			while (rs.next()) {
				System.out.println(2);
				ProgramsScheduled program = new ProgramsScheduled();
				program.setScheduled_program_id(Integer.parseInt(rs
						.getString("Scheduled_program_id")));
				program.setProgramName(rs.getString("ProgramName"));
				program.setLocationID(rs.getString("LocationID"));
				program.setStart_date(rs.getDate("start_date"));
				program.setEnd_date(rs.getDate("end_date"));
				program.setSessions_per_week(rs.getInt("sessions_per_week"));
				System.out.println(program);
				programList.add(program);
			}

		} catch (SQLException e) {

			throw new UniversityAdmissionException(
					"Program Shedule Not Selected", e);

		} finally {

		}
		return programList;
	}

	@Override
	public List<Application> getApplicationOnSheduledId(String ScheduleId)
			throws UniversityAdmissionException {

		Connection conn = null;
		List<Application> applicantList = new ArrayList<Application>();
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query = "SELECT * FROM Application where Scheduled_program_id=? and status=?";

		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, ScheduleId);
			pstm.setString(2, "accepted");
			rs = pstm.executeQuery();

			Application application = null;
			while (rs.next()) {
				application = new Application();
				application.setApplication_id(rs.getInt("Application_id"));
				application.setFull_name(rs.getString("full_name"));
				application.setDate_of_birth(rs.getDate("date_of_birth"));
				application.setHighest_qualification(rs
						.getString("highest_qualification"));
				application.setMarks_obtained(rs.getInt("marks_obtained"));
				application.setGoals(rs.getString("goals"));
				application.setEmail_id(rs.getString("email_id"));
				application.setScheduled_program_id(rs
						.getString("Scheduled_program_id"));
				application.setStatus(rs.getString("status"));
				application.setDate_Of_Interview(rs
						.getDate("Date_Of_Interview"));
				applicantList.add(application);
			}

		} catch (SQLException e) {

			// throw new
			// UniversityAdmissionException("Applicant Data Not Selected",e);
			e.printStackTrace();

		} finally {
		}
		return applicantList;
	}

	@Override
	public boolean updateApplicationDB(int id, String status)
			throws UniversityAdmissionException {
		Connection conn = null;
		List<Application> applicantList = new ArrayList<Application>();
		PreparedStatement pstm = null;
		int rec;
		String query = "update Application set status=? where Application_id=?";

		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, status);
			pstm.setInt(2, id);
			rec = pstm.executeUpdate();

			if (rec > 0) {
				return true;
			}

		} catch (SQLException e) {

			throw new UniversityAdmissionException(
					"Applicant Data Not Updated", e);

		} finally {
		}

		return false;
	}

	@Override
	public List<Application> showApplicantInfo(int id)
			throws UniversityAdmissionException {
		System.out.println("IndaoImpl");

		Connection conn = null;
		PreparedStatement pstm = null;

		List<Application> applicantList = new ArrayList<Application>();

		String qry = "SELECT Application_id,full_name,status,Scheduled_program_id FROM Application where Scheduled_program_id=?";
		try {
			System.out.println("xxx");
			conn = util.getConnection();
			pstm = conn.prepareStatement(qry);
			pstm.setInt(1, id);
			ResultSet rs = pstm.executeQuery();
			System.out.println("xxx");
			while (rs.next()) {
				System.out.println("xxx");
				Application appl = new Application();
				appl.setApplication_id(rs.getInt("Application_id"));
				appl.setFull_name(rs.getString("full_name"));
				appl.setStatus(rs.getString("status"));
				appl.setScheduled_program_id(rs
						.getString("Scheduled_program_id"));
				System.out.println(appl);
				applicantList.add(appl);
				System.out.println(appl);

			}

			return applicantList;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UniversityAdmissionException(
					"Problem occured while showing applicant Details", e);
		} finally {
			try {

				pstm.close();
				conn.close();

			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

	// /////////////////////////////////////////////////////////////////
	@Override
	public List<ProgramsScheduled> showProgramInfo(Date startdate, Date enddate)
			throws UniversityAdmissionException {

		Connection conn = null;
		PreparedStatement pstm = null;
		ProgramsScheduled prog = null;
		List<ProgramsScheduled> progList = new ArrayList<ProgramsScheduled>();

		String qry = "SELECT Scheduled_program_id,ProgramName  FROM Programs_Scheduled where(start_date>=?) AND (end_date<=?)";
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(qry);

			pstm.setDate(1, startdate);
			pstm.setDate(2, enddate);
			ResultSet rs = pstm.executeQuery();

			while (rs.next()) {
				prog = new ProgramsScheduled();

				prog.setScheduled_program_id(rs.getInt("Scheduled_program_id"));
				prog.setProgramName(rs.getString("ProgramName"));
				progList.add(prog);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UniversityAdmissionException(
					"Problem occured while showing program Details", e);
		} finally {
			try {

				pstm.close();
				conn.close();

			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		return progList;
	}

	public int getApplicationId() throws UniversityAdmissionException {
		int a = 0;

		Connection conn = null;
		PreparedStatement pstm = null;
		try {
			conn = util.getConnection();
			String query = "SELECT application_id.nextval from dual";
			pstm = conn.prepareStatement(query);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				a = rs.getInt(1);
			}
			System.out.println(a);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return a;

	}

	public List<ProgramsOffered> showAll() throws UniversityAdmissionException {
		Connection conn = null;
		PreparedStatement pstm = null;
		List<ProgramsOffered> myProg = new ArrayList<ProgramsOffered>();
		String query = "Select ProgramName,description,applicant_eligibility,duration,degree_certificate_offered from Programs_Offered";
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			ResultSet rst = pstm.executeQuery();
			while (rst.next()) {
				ProgramsOffered p = new ProgramsOffered();
				p.setProgramName(rst.getString("ProgramName"));
				p.setDescription(rst.getString("description"));
				p.setApplicantEligility(rst.getString("applicant_eligibility"));
				p.setDuration(rst.getInt("duration"));
				p.setDegree_certificate_offered(rst
						.getString("degree_certificate_offered"));

				myProg.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UniversityAdmissionException("Problem in show");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return myProg;
	}

	public int getProgramId(String programName)
			throws UniversityAdmissionException {
		ProgramsScheduled ps = new ProgramsScheduled();
		String status = null;
		Connection conn = null;
		PreparedStatement pstm = null;

		String query = "SELECT Scheduled_program_id FROM Programs_Scheduled WHERE ProgramName=?";
		try {

			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, programName);
			ResultSet rs = pstm.executeQuery();
			System.out.println(rs);
			while (rs.next()) {
				ps.setScheduled_program_id(Integer.parseInt(rs
						.getString("Scheduled_program_id")));
			}
			System.out.println(status);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ps.getScheduled_program_id();
	}

	@Override
	public int addApplicant(Application appl)
			throws UniversityAdmissionException {

		Connection conn = null;
		PreparedStatement pstm = null;
		int status = 0;
		String query = "Insert into Application(Application_id,full_name,date_of_birth,highest_qualification,marks_obtained,goals,email_id, Scheduled_program_id,status) values(?,?,?,?,?,?,?,?,?)";
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, appl.getApplication_id());
			pstm.setString(2, appl.getFull_name());
			pstm.setDate(3, appl.getDate_of_birth());
			pstm.setString(4, appl.getHighest_qualification());
			pstm.setInt(5, appl.getMarks_obtained());
			pstm.setString(6, appl.getGoals());
			pstm.setString(7, appl.getEmail_id());
			pstm.setString(8, appl.getScheduled_program_id());
			pstm.setString(9, "applied");

			status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("Data Inserted");
			}

		} catch (SQLException e) {

			e.printStackTrace();
			throw new UniversityAdmissionException("Problem in Exception");
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return appl.getApplication_id();

	}

	@Override
	public Application showStatus(int application_id)
			throws UniversityAdmissionException {

		Connection conn = null;
		PreparedStatement pstm = null;
		Application appl = new Application();
		String status = null;
		String query = "SELECT full_name,Scheduled_program_id,status FROM Application WHERE Application_id=?";
		try {

			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, application_id);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				appl.setApplication_id(application_id);
				appl.setFull_name(rs.getString("full_name"));
				appl.setScheduled_program_id(rs
						.getString("Scheduled_program_id"));
				appl.setStatus(rs.getString("status"));
			}
			System.out.println(status);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return appl;
	}

	// ////////////////////////////////////////////////////////////nhehali
	@Override
	public List<ProgramsOffered> getAllProgramDetails()
			throws UniversityAdmissionException {
		Connection conn = null;
		List<ProgramsOffered> prgmList = new ArrayList<ProgramsOffered>();
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query = "SELECT ProgramName,description,applicant_eligibility FROM Programs_Offered";

		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			rs = pstm.executeQuery();

			while (rs.next()) {

				ProgramsOffered program = new ProgramsOffered();
				program.setProgramName(rs.getString("ProgramName"));
				program.setDescription(rs.getString("description"));
				program.setApplicantEligility(rs
						.getString("applicant_eligibility"));
				prgmList.add(program);
			}

		} catch (SQLException e) {

			throw new UniversityAdmissionException("Program Data Not Selected",
					e);

		} finally {
		}
		return prgmList;
	}

	@Override
	public String insertLocationDetails(Location loc)
			throws UniversityAdmissionException {
		PreparedStatement stat = null;
		Connection connection = null;
		int rec;
		String locId = null;
		locId = getLocationId();

		String Query = "insert into Location values(?,?,?,?)";
		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, locId);
			stat.setString(2, loc.getCity());
			stat.setString(3, loc.getHstate());
			stat.setString(4, loc.getZip());
			rec = stat.executeUpdate();
			if (rec > 0) {
				System.out.println("f1");
				// locId=getLocationId();

			} else {

				throw new UniversityAdmissionException(
						"UNABLE TO INSERT LOCATION DETAILS");

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return locId;
	}

	private String getLocationId() throws UniversityAdmissionException {

		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query = "select location_id.NEXTVAL from dual";

		String loc;

		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			rs = pstm.executeQuery();
			if (rs.next()) {
				loc = String.valueOf(rs.getInt(1));
				System.out.println("Location" + loc);

				System.out.println("Hiii1" + loc);
				return loc;

			} else {

				throw new UniversityAdmissionException(" No LocId selected");
			}

		} catch (SQLException e) {

			throw new UniversityAdmissionException("No jndi connection", e);

		} finally {
		}

	}

	@Override
	public boolean insertScheduledDetails(ProgramsScheduled schedule)
			throws UniversityAdmissionException {

		PreparedStatement stat = null;
		Connection connection = null;
		int rec;
		String locId = null;

		String Query = "insert into Programs_Scheduled(Scheduled_program_id,ProgramName,LocationID,start_date,end_date,sessions_per_week)values(scheduled_program_id.nextval,?,?,?,?,?)";
		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, schedule.getProgramName());
			stat.setString(2, schedule.getLocationID());
			stat.setDate(3, schedule.getStart_date());
			stat.setDate(4, schedule.getEnd_date());
			stat.setInt(5, schedule.getSessions_per_week());
			rec = stat.executeUpdate();
			if (rec > 0) {
				return true;

			} else {

				return false;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return true;

	}

	@Override
	public boolean deleteSchedule(String id)
			throws UniversityAdmissionException {
		PreparedStatement stat = null;
		Connection connection = null;
		ResultSet rs = null;

		String Query = " DELETE FROM Programs_Scheduled WHERE Scheduled_program_id=?";
		try {
			connection = util.getConnection();
			stat = connection.prepareStatement(Query);
			stat.setString(1, id);
			rs = stat.executeQuery();
			if (rs.next()) {

				return true;

			} else {

				throw new UniversityAdmissionException(
						"CAN NOT DELETE SCHEDULE");

			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return false;
	}

	// /////////////////////////////////////////////////////////////////Modified////////////////////////////////////////
	public List<ProgramsScheduled> getAllProgramSheduled(String programName)
			throws UniversityAdmissionException {

		List<ProgramsScheduled> programList = new ArrayList<ProgramsScheduled>();
		Connection conn = null;

		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query = "SELECT * FROM Programs_Scheduled WHERE PROGRAMNAME=?";
		System.out.println("ps1");

		try {

			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, programName);
			rs = pstm.executeQuery();

			while (rs.next()) {
				System.out.println(2);
				ProgramsScheduled program = new ProgramsScheduled();
				program.setScheduled_program_id(Integer.parseInt(rs
						.getString("Scheduled_program_id")));
				program.setProgramName(rs.getString("ProgramName"));
				program.setLocationID(rs.getString("LocationID"));
				program.setStart_date(rs.getDate("start_date"));
				program.setEnd_date(rs.getDate("end_date"));
				program.setSessions_per_week(rs.getInt("sessions_per_week"));
				System.out.println(program);
				programList.add(program);
				System.out.println(programList);
			}

		} catch (SQLException e) {

			throw new UniversityAdmissionException(
					"Program Shedule Not Selected", e);

		} finally {

		}
		return programList;
	}

}
